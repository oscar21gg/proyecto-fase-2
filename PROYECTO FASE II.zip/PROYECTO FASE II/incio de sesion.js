const username = document.getElementById("texto");

username.addEventListener("input", function () {
    username.style.color = "white";
});

const password = document.getElementById("texto");

password.addEventListener("input", function () {
    password.style.color = "white";
});

function loguear()
{

var user= document.getElementById("username").value;

var pass= document.getElementById("password").value;

if(user=="seller456" && pass=="Intro123") {

    window.location="comprador.html";

} else if (user === "dancabello" && pass === "J5*asdRD.s") {

    window.location.href = "vendedor.html";

} else if (user === "root" && pass === "dochouse") {

    window.location.href = "admin.html";

} else {

    alert("Datos incorrectos");
}
}