const no = document.getElementById("texto");

no.addEventListener("input", function () {
    no.style.color = "white";
});
