let questions = [
  {
  numb: 1,
  question: "Qué dato se usa para los decimales?",
  answer: "Float",
  options: [
    "Float",
    "String",
    "Int",
    "Char"
  ]
},
  {
  numb: 2,
  question: ". ¿En qué año se fundo C++ ?",
  answer: "1980",
  options: [
    "1980",
    "2006",
    "1999",
    "2010"
  ]
},
  {
  numb: 3,
  question: "¿Para que se utiliza c++?",
  answer: "Todas las anteriores",
  options: [
    "Desarrollo de juegos",
    "Deasarrollo de sistemas web",
    "Sistemas operativos",
    "Todas las anteriores"
  ]
},
  {
  numb: 4,
  question: "¿Cuál considera una característica clave de la programación orientada a objetos en C++?",
  answer: "Clases y objetos",
  options: [
    "Procedimientos",
    "Variables globales",
    "Estructuras de control",
    "Clases y objetos"
  ]
},
  {
  numb: 5,
  question: "¿Cuál es el propósito principal de los punteros en C++??",
  answer: "Referenciar la dirección de memoria de una variable",
  options: [
    "Crear funciones recursivas",
    "Almacenar valores enteros",
    " Realizar operaciones aritméticas",
    "Referenciar la dirección de memoria de una variable"
  ]
},
];
