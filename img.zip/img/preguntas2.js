let questions = [
  {
  numb: 1,
  question: "¿Cuál de las siguientes es la forma correcta de declarar una variable en Python??",
  answer: "x = 10",
  options: [
    "int x = 10",
    " var x = 10",
    "x = 10",
    "string x = Hola"
  ]
},
  {
  numb: 2,
  question: "¿Cuál es el resultado de la siguiente operación: 5 % 2?",
  answer: "1",
  options: [
    "2.5",
    "2",
    "1",
    "Error"
  ]
},
  {
  numb: 3,
  question: "¿Para qué se utiliza la palabra clave def en Python?",
  answer: " Para definir una función",
  options: [
    "Para definir una variable",
    " Para definir una función",
    "Para definir una clase",
    "Para definir un módulo"
  ]
},
  {
  numb: 4,
  question: "¿Cuál de las siguientes estructuras de datos es inmutable en Python?",
  answer: "Tuplas",
  options: [
    "Listas",
    "Diccionarios",
    "Tuplas",
    " Todas las anteriores"
  ]
},
  {
  numb: 5,
  question: "¿ En qué año se creó Python?",
  answer: "1991 qué año se creó Python",
  options: [
    "1986",
    "2024",
    "2000",
    "1991"
  ]
},
];
